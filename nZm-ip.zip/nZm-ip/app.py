import os
import logging
import sqlite3
from flask import Flask, request, render_template, redirect, url_for, flash, g

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "a-secure-default-key-for-development")
DATABASE = "ips.db"

# Function to get real public IP address using headers (more reliable in proxy environments)
def get_real_ip():
    # Check X-Forwarded-For header first (common for proxies)
    if request.headers.get("X-Forwarded-For"):
        # If multiple IPs in the header, take the first one (client IP)
        return request.headers.get("X-Forwarded-For").split(',')[0].strip()
    
    # Check other common proxy headers if X-Forwarded-For is not available
    if request.headers.get("X-Real-IP"):
        return request.headers.get("X-Real-IP")
    
    # Fall back to the remote_addr
    return request.remote_addr

# Database helper functions
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT UNIQUE,
                name TEXT,
                user_agent TEXT,
                screen_width INTEGER,
                screen_height INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.commit()

# دالة لاستخراج أول 3 أجزاء من عنوان IP للمقارنة
def get_ip_prefix(ip):
    return ".".join(ip.split(".")[:3])  # مثال: 192.168.1.55 ➝ 192.168.1

@app.route("/", methods=["GET", "POST"])
def index():
    # Use the function to get the real public IP
    user_ip = get_real_ip()
    
    # Get user agent (browser and device info)
    user_agent = request.headers.get("User-Agent", "Unknown")
    
    # For testing in development environment or manual override from form
    if request.args.get('ip'):
        user_ip = request.args.get('ip')
        
    message = ""
    message_type = ""
    existing_data = None
    similar_name = None
    is_custom_ip = False
    
    # Check if we should display the IP form
    if request.args.get('set_ip') == '1':
        is_custom_ip = True
    
    db = get_db()
    cursor = db.cursor()

    # التحقق إذا كان الـ IP الحالي مسجل بالفعل
    cursor.execute("SELECT name, user_agent, screen_width, screen_height FROM users WHERE ip = ?", (user_ip,))
    row = cursor.fetchone()

    if row:
        existing_data = {
            'name': row[0],
            'user_agent': row[1],
            'screen_width': row[2],
            'screen_height': row[3]
        }
        message = f"عنوان IP {user_ip} مسجل بالفعل باسم: {row[0]}"
        message_type = "info"
    else:
        # البحث عن IP مشابه (نفس أول 3 خانات)
        ip_prefix = get_ip_prefix(user_ip)
        cursor.execute("SELECT name FROM users WHERE ip LIKE ?", (ip_prefix + "%",))
        similar_row = cursor.fetchone()
        
        if similar_row:
            similar_name = similar_row[0]
            message = f"عنوان IP مشابه مسجل بالفعل باسم: {similar_name}"
            message_type = "warning"
        
        if request.method == "POST":
            name = request.form.get("name")
            screen_width = request.form.get("screen_width", 0)
            screen_height = request.form.get("screen_height", 0)
            
            if name:
                try:
                    cursor.execute("""
                        INSERT INTO users (ip, name, user_agent, screen_width, screen_height) 
                        VALUES (?, ?, ?, ?, ?)
                    """, (user_ip, name, user_agent, screen_width, screen_height))
                    db.commit()
                    message = f"تم تسجيل {name} بعنوان IP: {user_ip}"
                    message_type = "success"
                    flash(message, message_type)
                    return redirect(url_for('index'))
                except sqlite3.IntegrityError:
                    message = f"عنوان IP {user_ip} مسجل بالفعل!"
                    message_type = "danger"

    return render_template("index.html", 
                          user_ip=user_ip,
                          user_agent=user_agent, 
                          message=message, 
                          message_type=message_type,
                          existing_data=existing_data, 
                          similar_name=similar_name,
                          is_custom_ip=is_custom_ip)

@app.route("/registered")
def registered_ips():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, ip, name, user_agent, screen_width, screen_height, created_at FROM users ORDER BY created_at DESC")
    users = cursor.fetchall()
    return render_template("registered_ips.html", users=users)

# Initialize the database
init_db()
